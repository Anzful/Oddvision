var OddvisionConfig = {
    // Primary: Groq (30 req/min, 14,400/day) - FASTEST ⚡
    apiKey: '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',
  
  // Backup: OpenRouter (200 req/day, 20 req/min on free models) 🆓
  openrouterKey: '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',

  // Supabase Auth & DB
  supabaseUrl: 'https://czetxxmjcvfiavwzcvqb.supabase.co',
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN6ZXR4eG1qY3ZmaWF2d3pjdnFiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2NjU0MDAsImV4cCI6MjA3OTI0MTQwMH0.E098WUiAP7AykQepyJR58cqU6Li6B2JrZdrSag06iVw'
};